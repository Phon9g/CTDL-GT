#include <iostream>
#include <queue>
using namespace std;

// Cấu trúc hàng đợi dùng mảng
#define MAX 999
struct QueueInt {
    int arr[MAX]; // Mảng chứa phần tử
    int front, rear; // Chỉ số đầu và cuối của hàng đợi
};

// Khởi tạo hàng đợi
void InitQueue(QueueInt &q) {
    q.front = q.rear = -1;
}

// Kiểm tra hàng đợi có rỗng không
bool IsEmpty(QueueInt q) {
    return q.front == -1;
}

// Kiểm tra hàng đợi có đầy không
bool IsFull(QueueInt q) {
    return q.rear == MAX - 1;
}

// Thêm phần tử vào hàng đợi
void Enqueue(QueueInt &q, int value) {
    if (IsFull(q)) {
        cout << "Queue đầy!" << endl;
        return;
    }
    if (IsEmpty(q)) q.front = 0;
    q.arr[++q.rear] = value;
}

// Lấy phần tử ra khỏi hàng đợi
int Dequeue(QueueInt &q) {
    if (IsEmpty(q)) {
        cout << "Queue rỗng!" << endl;
        return -1;
    }
    int value = q.arr[q.front];
    if (q.front == q.rear) InitQueue(q);
    else q.front++;
    return value;
}

// Xem phần tử đầu
int PeekQueue(QueueInt q) {
    if (IsEmpty(q)) {
        cout << "Queue rỗng!" << endl;
        return -1;
    }
    return q.arr[q.front];
}

// Xóa hàng đợi
void ClearQueue(QueueInt &q) {
    InitQueue(q);
}



// b. Xếp lịch cặp múa nam nữ
void DancePairing(queue<string> males, queue<string> females) {
    cout << "Danh sách cặp nhảy: " << endl;
    while (!males.empty() && !females.empty()) {
        cout << males.front() << " - " << females.front() << endl;
        males.pop();
        females.pop();
    }
    if (!males.empty()) cout << "Còn " << males.size() << " nam chưa có bạn nhảy." << endl;
    if (!females.empty()) cout << "Còn " << females.size() << " nữ chưa có bạn nhảy." << endl;
}

// c. Thuật toán Radix Sort
void RadixSort(int arr[], int n) {
    queue<int> buckets[10]; // Mảng 10 hàng đợi (0-9)
    int maxVal = arr[0], exp = 1;
    for (int i = 1; i < n; i++)
        if (arr[i] > maxVal) maxVal = arr[i];
    while (maxVal / exp > 0) {
        for (int i = 0; i < n; i++)
            buckets[(arr[i] / exp) % 10].push(arr[i]);
        int index = 0;
        for (int i = 0; i < 10; i++) {
            while (!buckets[i].empty()) {
                arr[index++] = buckets[i].front();
                buckets[i].pop();
            }
        }
        exp *= 10;
    }
}

int main() {
    // Test hàng đợi
    QueueInt q;
    InitQueue(q);
    int n, value;
    cout << "Nhập số lượng phần tử: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        cout << "Nhập phần tử thứ " << i + 1 << ": ";
        cin >> value;
        Enqueue(q, value);
    }
cout << "Phần tử đầu tiên: " << PeekQueue(q) << endl;
cout << "Lấy ra: " << Dequeue(q) << endl;
cout << "Phần tử đầu mới: " << PeekQueue(q) << endl;

    // Xếp lịch cặp múa
    queue<string> males, females;
    int maleCount, femaleCount;
    string name;
cout << "Nhập số lượng nam: "; cin >> maleCount;
    for (int i = 0; i < maleCount; i++) {
        cout << "Nhập tên nam thứ " << i + 1 << ": ";
        cin >> name;
        males.push(name);
    }
cout << "Nhập số lượng nữ: "; cin >> femaleCount;
    for (int i = 0; i < femaleCount; i++) {
        cout << "Nhập tên nữ thứ " << i + 1 << ": ";
        cin >> name;
        females.push(name);
    }
    DancePairing(males, females);

    // Radix Sort
cout << "Nhập số lượng phần tử cho Radix Sort: ";
cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++) {
cout << "Nhập phần tử thứ " << i + 1 << ": ";
cin >> arr[i];
    }
    RadixSort(arr, n);
cout << "Mảng sau khi sắp xếp: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
cout << endl;
    return 0;
}
