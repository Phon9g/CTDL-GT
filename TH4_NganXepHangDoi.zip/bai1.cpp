#include <iostream>
#include <stack>
#include <string>
using namespace std;



// Cấu trúc ngăn xếp dùng mảng
#define MAX 999
struct StackInt {
    int arr[MAX]; // Mảng chứa phần tử
    int top;      // Chỉ số đỉnh ngăn xếp
};

// Hàm khởi tạo ngăn xếp
void InitStack(StackInt &s) {
    s.top = -1;
}

// Kiểm tra ngăn xếp có rỗng không
bool IsEmpty(StackInt s) {
    return s.top == -1;
}

// Kiểm tra ngăn xếp có đầy không
bool IsFull(StackInt s) {
    return s.top == MAX - 1;
}

// Thêm phần tử vào ngăn xếp
void PushStack(StackInt &s, int value) {
    if (IsFull(s)) {
        cout << "ngăn xếp full" << endl;
        return;
    }
    s.arr[++s.top] = value;
}

// Lấy phần tử ra khỏi ngăn xếp
int PopStack(StackInt &s) {
    if (IsEmpty(s)) {
        cout << "Ngăn xếp trống" << endl;
        return -1;
    }
    return s.arr[s.top--];
}

// Lấy giá trị đỉnh nhưng không xóa
int PeekStack(StackInt s) {
    if (IsEmpty(s)) {
        cout << "Ngăn xếp trống" << endl;
        return -1;
    }
    return s.arr[s.top];
}

// Xóa toàn bộ ngăn xếp
void Clear(StackInt &s) {
    s.top = -1;
}
// b. Đảo số bằng ngăn xếp
void ReverseNumber(int n) {
    StackInt s;
    InitStack(s);
    while (n > 0) {
        PushStack(s, n % 10);
        n /= 10;
    }
    cout << "Số đảo ngược: ";
    while (!IsEmpty(s)) {
        cout << PopStack(s);
    }
    cout << endl;
}

// c. Kiểm tra xâu đối xứng
bool IsPalindrome(string str) {
    stack<char> s;
    for (char c : str) {
        s.push(c);
    }
    for (char c : str) {
        if (s.top() != c) return false;
        s.pop();
    }
    return true;
}

// d. Đổi số thập phân sang nhị phân
void DecimalToBinary(int n) {
    stack<int> s;
    while (n > 0) {
        s.push(n % 2);
        n /= 2;
    }
    cout << "Dạng nhị phân: ";
    while (!s.empty()) {
        cout << s.top();
        s.pop();
    }
    cout << endl;
}

// e. Chuyển biểu thức trung tố sang hậu tố (chưa tính giá trị)
int precedence(char c) {
    if (c == '+' || c == '-') return 1;
    if (c == '*' || c == '/') return 2;
    return 0;
}

string InfixToPostfix(string infix) {
    stack<char> s;
    string postfix = "";
    for (char c : infix) {
        if (isdigit(c)) postfix += c;
        else if (c == '(') s.push(c);
        else if (c == ')') {
            while (!s.empty() && s.top() != '(') {
                postfix += s.top();
                s.pop();
            } s.pop();
        } 
        else {
            while (!s.empty() && precedence(s.top()) >= precedence(c)) {
                postfix += s.top();
                s.pop();
            }
            s.push(c);
        }
    }
    while (!s.empty()) {
        postfix += s.top();
        s.pop();
    }
    return postfix;
}

int main() {
    // Hàm nhập và xuất
    int num;
cout << "Nhập số nguyên cần được đảo ngược: ";
cin >> num;
    ReverseNumber(num);
    
    string str;
cout << "Nhập một xâu để kiểm tra đối xứng: ";
cin >> str;
cout << "Xâu " << str << (IsPalindrome(str) ? " là đối xứng" : " không đối xứng") << endl;
    
    int decimal;
cout << "Nhập một số thập phân: ";
cin >> decimal;
    DecimalToBinary(decimal);
    
    string infix;
cout << "Nhập biểu thức trung tố: ";
cin >> infix;
cout << "Biểu thức hậu tố: " << InfixToPostfix(infix) << endl;
    



 return 0;
}
