/* Cho một cây nhị phân tìm kiếm với nút gốc là Root, giá trị lưu trữ
tại mỗi nút là một số nguyên (int). Hãy viết hàm tìm phần tử nhỏ
nhất và lớn nhất trong cây.
cây nhị phân 10,5,3,9,7,15,12.18,20 theo LNR
*/

#include <iostream>

using namespace std;

// Cấu trúc dữ liệu
struct Node {
    int info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;

// Hàm thêm phần tử vào cây nhị phân tìm kiếm
void Insert(TREE &root, int x) {
    if (root == NULL) {
        root = new Node{x, NULL, NULL};
        return;
    }
    if (x < root->info) Insert(root->pLeft, x);
    else Insert(root->pRight, x);
}

// Hàm tìm phần tử nhỏ nhất
Node* NhoNhat(TREE root) {
    if (root == NULL) return NULL;
    Node* lc = root;
    while (lc->pLeft) lc = lc->pLeft;
    return lc;
}

// Hàm tìm phần tử lớn nhất
Node* LonNhat(TREE root) {
    if (root == NULL) return NULL;
    Node* lc = root;
    while (lc->pRight) lc = lc->pRight;
    return lc;
}

// Hàm duyệt LNR (Inorder)
void LNR(TREE root) {
    if (root == NULL) return;
    LNR(root->pLeft);
    cout << root->info << " ";
    LNR(root->pRight);
}

int main() {
    TREE root = NULL;
    int arr[] = {10, 5, 3, 9, 7, 15, 12, 18, 20};
    for (int x : arr) Insert(root, x);
    
    cout << "Cay theo thu tu LNR: ";
    LNR(root);
    cout << endl;
    
    Node* minNode = NhoNhat(root);
    Node* maxNode = LonNhat(root);
    if (minNode) cout << "Phan tu nho nhat: " << minNode->info << endl;
    if (maxNode) cout << "Phan tu lon nhat: " << maxNode->info << endl;
    
    return 0;
}

/*Cay theo thu tu LNR: 3 5 7 9 10 12 15 18 20 
Phan tu nho nhat: 3
Phan tu lon nhat: 20
*/