/* Cho một cây nhị phân có cấu trúc nút là NODE hãy:
• Viết hàm để tính tổng số nút có một nhánh con (con trái HAY con phải)
bằng cách dùng thuật toán duyệt nút gốc giữa NLR;
• Thiết lập một công thức đệ quy để thực hiện yêu cầu của câu trên. Cài đặt
công thức này thành hàm.
Câu b: Số lượng nút một con trong cây nhị phân bằng 1 cộng số
lượng nút một con trong cây nhị phân con trái cộng số lượng nút
một con trong cây nhị phân con phải nếu nút gốc có một con.
Ngược lại số lượng nút một con trong cây nhị phân bằng số lượng
nút một con trong cây nhị phân con trái cộng số lượng nút một con
trong cây nhị phân con phải.
*/
#include <iostream>

using namespace std;

struct Node {
    int info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;

// Hàm tạo nút mới
Node* CreateNode(int x) {
    Node* newNode = new Node;
    newNode->info = x;
    newNode->pLeft = newNode->pRight = NULL;
    return newNode;
}

// Hàm thêm phần tử vào cây nhị phân
void Insert(TREE &root, int x) {
    if (root == NULL) {
        root = CreateNode(x);
        return;
    }
    if (x < root->info) Insert(root->pLeft, x);
    else Insert(root->pRight, x);
}

// Hàm đệ quy đếm số nút có một nhánh con (NLR)
int DemMotCon(TREE t) {
    if (t == NULL) return 0;
    int count = 0;
    if ((t->pLeft && !t->pRight) || (!t->pLeft && t->pRight)) {
        count = 1;
    }
    return count + DemMotCon(t->pLeft) + DemMotCon(t->pRight);
}

// Hàm duyệt cây theo NLR để kiểm tra cây có đúng không
void DuyetNLR(TREE root) {
    if (root != NULL) {
        cout << root->info << " ";
        DuyetNLR(root->pLeft);
        DuyetNLR(root->pRight);
    }
}

int main() {
    TREE root = NULL;
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    
    if (n <= 0) {
        cout << "Cay rong!" << endl;
        return 0;
    }
    
    cout << "Nhap cac phan tu: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        Insert(root, x);
    }
    
    cout << "Cay duyet theo NLR: ";
    DuyetNLR(root);
    cout << endl;
    
    cout << "So nut co mot con trong cay: " << DemMotCon(root) << endl;
    return 0;
}
