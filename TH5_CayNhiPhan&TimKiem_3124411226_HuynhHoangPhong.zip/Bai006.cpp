/*Hãy phát biểu công thức đệ quy để tính các giá trị sau đây:
• Số nút trong cây nhị phân tìm kiếm.
• Tổng giá trị các nút trong cây (giả sử mỗi phần tử là một số nguyên).
• Cài đặt thành hàm các công thức đã nêu ở trên.
Số nút trong cây nhị phân tìm kiếm bằng số nút
trong cây nhị phân tìm kiếm trong cây con trái
cộng số nút trong cây nhị phân tìm kiếm trong
cây con phải cộng 1.
Tổng giá trị các nút trong cây tìm kiếm bằng tổng giá
trị các nút trong cây nhị phân tìm kiếm con trái cộng
tổng giá trị các nút trong cây nhị phân tìm kiếm con
phải cộng giá trị tại nút gốc.
*/
#include <iostream>

using namespace std;

struct Node {
    int info;
    Node* pLeft;
    Node* pRight;
};

typedef Node* TREE;

// Hàm đếm số nút trong cây
int DemNode(TREE t) {
    if (t == NULL) return 0;
    return 1 + DemNode(t->pLeft) + DemNode(t->pRight);
}

// Hàm tính tổng giá trị các nút trong cây
int TongNode(TREE t) {
    if (t == NULL) return 0;
    return t->info + TongNode(t->pLeft) + TongNode(t->pRight);
}

int main() {
    TREE t = NULL; // Khởi tạo cây rỗng

    cout << "So nut trong cay: " << DemNode(t) << endl;
    cout << "Tong gia tri cac nut: " << TongNode(t) << endl;

    return 0;
}
