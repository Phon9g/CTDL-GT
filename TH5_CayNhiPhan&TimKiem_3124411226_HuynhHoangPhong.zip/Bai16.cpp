/* Hãy viết hàm thực hiện thao tác xoá phần tử có khoá X. Cách xoá
như sau:
• Nếu phần tử X có tồn tại giảm field So_lan của nó một đơn vị.
• Nếu phần tử X không tồn tại. Thông báo.
• Hãy viết hàm in lên màn hình giá trị của các phần tử đang tồn tại
trong cây theo thứ tự NLR.
Cho một cây nhị phân tìm kiếm t có cấu trúc nút là BST_NODE được khai
báo như sau:
11.struct BST_NODE{
12. int Key; // Khóa của nút
13. int So_lan; // Số lần xuất hiện.
14. struct BST_NODE*Left,*Right;
15.};
16.struct BST_TREE
17.{
18. struct BST_NODE *pRoot;

// Nút gốc của cây.

19.};
20.struct BST_TREE t; // Cây t

Câu b: Hãy viết hàm in lên màn hình giá trị của
các phần tử đang tồn tại trong cây theo thứ tự
NLR.
*/
#include <iostream>
using namespace std;

// Định nghĩa cấu trúc của một nút trong cây BST
struct BST_NODE {
    int Key;          // Khóa của nút
    int So_lan;       // Số lần xuất hiện của khóa này
    BST_NODE* Left;   // Con trái
    BST_NODE* Right;  // Con phải
};

// Định nghĩa cấu trúc của cây tìm kiếm nhị phân
struct BST_TREE {
    BST_NODE* pRoot; // Nút gốc của cây
};

// Hàm tìm và giảm số lần xuất hiện của một phần tử có khóa X
int DeleteNode(BST_NODE*& Root, int x) {
    if (Root == NULL) {
        return 0; // Không tìm thấy phần tử
    }
    if (Root->Key == x) { // Nếu tìm thấy phần tử có khóa x
        if (Root->So_lan > 0) {
            Root->So_lan--; // Giảm số lần xuất hiện đi 1
            return 1; // Thành công
        }
        return 0; // Phần tử đã tồn tại nhưng không còn xuất hiện
    }
    if (x < Root->Key) {
        return DeleteNode(Root->Left, x); // Tìm tiếp bên trái
    }
    return DeleteNode(Root->Right, x); // Tìm tiếp bên phải
}

// Hàm gọi DeleteNode và hiển thị kết quả
void XoaGiaTri(BST_TREE& t, int x) {
    int kq = DeleteNode(t.pRoot, x);
    if (kq == 0)
        cout << "Khong ton tai X" << endl;
    else
        cout << "Xoa thanh cong." << endl;
}

// Hàm duyệt cây theo thứ tự NLR (Node-Left-Right)
void NLR(BST_NODE* Root) {
    if (Root == NULL) {
        return; // Nếu cây rỗng, dừng lại
    }
    if (Root->So_lan > 0) {
        cout << Root->Key << " "; // In giá trị nếu số lần xuất hiện > 0
    }
    NLR(Root->Left);  // Duyệt cây con bên trái
    NLR(Root->Right); // Duyệt cây con bên phải
}

// Hàm duyệt cây và in các phần tử đang tồn tại
void LietKe(BST_TREE t) {
    NLR(t.pRoot);
    cout << endl;
}

int main() {
    BST_TREE t;
    t.pRoot = NULL; // Khởi tạo cây rỗng
    
    // Code để thêm phần tử vào cây và kiểm tra xóa có thể bổ sung sau
    
    return 0;
}
