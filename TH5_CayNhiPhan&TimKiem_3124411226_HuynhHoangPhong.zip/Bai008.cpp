/*Định nghĩa hàm duyệt và xuất cây nhị phân các
số thực ra tập tin nhị phân data.out theo phương
pháp LNR.
*/

#include <iostream>
#include <cstdio> // Thư viện thao tác với file

using namespace std;

// Định nghĩa cấu trúc cây nhị phân
struct Node {
    float info;
    Node* pLeft;
    Node* pRight;
};

typedef Node* TREE;

// Hàm khởi tạo cây
void KhoiTaoCay(TREE &t) {
    t = NULL;
}

// Hàm thêm phần tử vào cây nhị phân
void ThemNode(TREE &t, float x) {
    if (t == NULL) {
        t = new Node;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        ThemNode(t->pLeft, x);
    } else {
        ThemNode(t->pRight, x);
    }
}

// Hàm duyệt cây theo thứ tự LNR và ghi vào file
void LNR(TREE t, FILE* fp) {
    if (t == NULL) return;
    LNR(t->pLeft, fp);
    fwrite(&t->info, sizeof(float), 1, fp);
    LNR(t->pRight, fp);
}

// Hàm xuất cây ra file nhị phân
int Xuat(const char* filename, TREE t) {
    FILE* fp = fopen(filename, "wb"); // Sử dụng dấu " chuẩn
    if (fp == NULL) return 0;
    LNR(t, fp);
    fclose(fp);
    return 1;
}

// Hàm đọc dữ liệu từ file nhị phân và hiển thị
void DocFile(const char* filename) {
    FILE* fp = fopen(filename, "rb");
    if (fp == NULL) {
        cout << "Không thể mở file!\n";
        return;
    }
    float temp;
    while (fread(&temp, sizeof(float), 1, fp)) {
        cout << temp << " ";
    }
    fclose(fp);
}

int main() {
    TREE t;
    KhoiTaoCay(t);

    // Thêm dữ liệu vào cây
    ThemNode(t, 5.3);
    ThemNode(t, 2.1);
    ThemNode(t, 8.7);
    ThemNode(t, 1.5);
    ThemNode(t, 3.6);

    // Xuất dữ liệu ra file nhị phân
    if (Xuat("data.out", t)) {
        cout << "Ghi dữ liệu vào file thành công.\n";
    } else {
        cout << "Ghi file thất bại.\n";
    }

    // Đọc lại dữ liệu từ file để kiểm tra
    cout << "Dữ liệu trong file: ";
    DocFile("data.out");

    return 0;
}
