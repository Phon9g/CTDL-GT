/*Bài 33:
• Hãy cài đặt thuật toán duyệt cây nhị phân (NLR) không dùng đệ quy (dùng
stack).
• Hãy cài đặt thuật toán duyệt cây nhị phân theo mức không dùng đệ quy
(dùng queue).

*/

#include <iostream>
#include <stack>
#include <queue>

using namespace std;

// Định nghĩa cấu trúc của một nút trong cây nhị phân
struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

// Duyệt cây theo thứ tự NLR không dùng đệ quy (dùng stack)
void preorderTraversal(TreeNode* root) {
    if (root == nullptr) return;
    
    stack<TreeNode*> st;
    st.push(root);
    
    while (!st.empty()) {
        TreeNode* node = st.top();
        st.pop();
        cout << node->val << " ";
        
        // Push phải trước, trái sau để đảm bảo thứ tự NLR
        if (node->right) st.push(node->right);
        if (node->left) st.push(node->left);
    }
}

// Duyệt cây theo từng mức không dùng đệ quy (dùng queue)
void levelOrderTraversal(TreeNode* root) {
    if (root == nullptr) return;
    
    queue<TreeNode*> q;
    q.push(root);
    
    while (!q.empty()) {
        TreeNode* node = q.front();
        q.pop();
        cout << node->val << " ";
        
        // Thêm các nút con vào hàng đợi theo thứ tự từ trái sang phải
        if (node->left) q.push(node->left);
        if (node->right) q.push(node->right);
    }
}

int main() {
    // Tạo một cây ví dụ
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->right->left = new TreeNode(6);
    root->right->right = new TreeNode(7);
    
    cout << "Duyệt cây theo NLR :  ";
    preorderTraversal(root);
    cout << endl;
    
    cout << "Duyệt cây theo từng mức : ";
    levelOrderTraversal(root);
    cout << endl;
    
    return 0;
}
