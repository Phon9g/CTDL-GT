/*Định nghĩa hàm duyệt và xuất cây nhị phân các
số thực ra tập tin nhị phân data.out theo phương
pháp LRN.

*/

#include <iostream>
#include <cstdio> // Thư viện hỗ trợ làm việc với tập tin

using namespace std;

// Định nghĩa cấu trúc một nút trong cây nhị phân
struct node {
    float info;        // Giá trị của nút (số thực)
    struct node* pLeft;  // Con trỏ trỏ đến cây con bên trái
    struct node* pRight; // Con trỏ trỏ đến cây con bên phải
};

typedef struct node NODE; // Định danh NODE thay cho struct node
typedef NODE* TREE;       // Định danh TREE thay cho con trỏ NODE

// Hàm duyệt cây theo thứ tự LRN (Left - Right - Node) và ghi vào tập tin nhị phân
void LRN(TREE t, FILE* fp) {
    if (t == NULL) // Nếu cây rỗng, thoát khỏi hàm
        return;
    
    LRN(t->pLeft, fp);  // Đệ quy duyệt cây con bên trái
    LRN(t->pRight, fp); // Đệ quy duyệt cây con bên phải
    
    // Ghi giá trị của nút hiện tại vào tập tin nhị phân
    fwrite(&t->info, sizeof(float), 1, fp);
}

// Hàm xuất cây nhị phân ra tập tin nhị phân theo phương pháp LRN
int Xuat(const char* filename, TREE t) {
    FILE* fp = fopen(filename, "wb"); // Mở tập tin để ghi nhị phân
    if (fp == NULL) // Kiểm tra xem có mở được tập tin không
        return 0;   // Nếu không, trả về 0 (thất bại)
    
    LRN(t, fp); // Gọi hàm duyệt cây theo LRN và ghi vào tập tin
    fclose(fp); // Đóng tập tin sau khi ghi xong
    
    return 1; // Trả về 1 (thành công)
}

int main() {
    // Phần này chưa có cây để xuất, có thể thêm code tạo cây tại đây
    TREE root = NULL; // Ban đầu cây rỗng
    
    // Gọi hàm xuất cây (nếu có dữ liệu thì sẽ ghi ra file "data.out")
    if (Xuat("data.out", root)) {
        cout << "Ghi file thanh cong!" << endl;
    } else {
        cout << "Loi khi mo file!" << endl;
    }
    
    return 0;
}
