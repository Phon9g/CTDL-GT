/* Định nghĩa hàm duyệt và xuất cây nhị phân các
số thực ra tập tin nhị phân data.out theo phương
pháp NLR.

*/

#include <iostream>
#include <cstdio>

using namespace std;

struct node {
    float info;
    struct node *pLeft;
    struct node *pRight;
};

typedef struct node NODE;
typedef NODE* TREE;

void NLR(TREE t, FILE *fp) {
    if (t == NULL) return;
    fwrite(&t->info, sizeof(float), 1, fp);
    NLR(t->pLeft, fp);
    NLR(t->pRight, fp);
}

int Xuat(char *filename, TREE t) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL) return 0;
    NLR(t, fp);
    fclose(fp);
    return 1;
}

NODE* CreateNode(float x) {
    NODE* p = new NODE;
    if (p == NULL) return NULL;
    p->info = x;
    p->pLeft = NULL;
    p->pRight = NULL;
    return p;
}

void InsertNode(TREE &t, float x) {
    if (t == NULL) {
        t = CreateNode(x);
        return;
    }
    if (x < t->info) InsertNode(t->pLeft, x);
    else InsertNode(t->pRight, x);
}

void NhapCay(TREE &t) {
    int n;
    float x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        cout << "Nhap so thu " << i + 1 << ": ";
        cin >> x;
        InsertNode(t, x);
    }
}

int main() {
    TREE t = NULL;
    NhapCay(t);
    
    if (Xuat("data.out", t)) 
        cout << "Ghi file thanh cong!\n";
    else 
        cout << "Ghi file that bai!\n";

    return 0;
}
