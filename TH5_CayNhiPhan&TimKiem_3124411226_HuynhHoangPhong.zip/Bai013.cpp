/* Định nghĩa hàm lưu cây nhị phân tìm kiếm các số
thực xuống tập tin nhị phân sao cho khi đọc dữ
liệu từ file ta có thể tạo lại được cây ban đầu.

*/
#include <iostream>
#include <cstdio>

using namespace std;

struct node {
    float info;
    struct node *pLeft;
    struct node *pRight;
};

typedef struct node NODE;
typedef NODE* TREE;

// Hàm khởi tạo cây
void KhoiTaoCay(TREE &t) {
    t = NULL;
}

// Hàm thêm một phần tử vào cây
void ThemNode(TREE &t, float x) {
    if (t == NULL) {
        t = new NODE;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        ThemNode(t->pLeft, x);
    } else {
        ThemNode(t->pRight, x);
    }
}

// Duyệt cây theo thứ tự NLR và ghi xuống file
void NLR(TREE t, FILE *fp) {
    if (t == NULL)
        return;
    fwrite(&t->info, sizeof(float), 1, fp);
    NLR(t->pLeft, fp);
    NLR(t->pRight, fp);
}

// Hàm ghi cây xuống file nhị phân
int Xuat(char *filename, TREE t) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    NLR(t, fp);
    fclose(fp);
    return 1;
}

// Đọc dữ liệu từ file và tạo lại cây BST
int Nhap(char *filename, TREE &t) {
    FILE *fp = fopen(filename, "rb");
    if (fp == NULL)
        return 0;
    float x;
    while (fread(&x, sizeof(float), 1, fp)) {
        ThemNode(t, x);
    }
    fclose(fp);
    return 1;
}

// Hàm duyệt cây LNR để kiểm tra
void LNR(TREE t) {
    if (t == NULL)
        return;
    LNR(t->pLeft);
    cout << t->info << " ";
    LNR(t->pRight);
}

int main() {
    TREE t;
    KhoiTaoCay(t);
    float arr[] = {5.2, 2.1, 8.7, 1.5, 3.3, 7.6, 9.9};
    int n = sizeof(arr) / sizeof(arr[0]);
    
    for (int i = 0; i < n; i++) {
        ThemNode(t, arr[i]);
    }
    
    char filename[] = "bst_data.dat";
    Xuat(filename, t);
    
    TREE t2;
    KhoiTaoCay(t2);
    Nhap(filename, t2);
    
    cout << "Cay doc tu file (LNR): ";
    LNR(t2);
    cout << endl;
    
    return 0;
}