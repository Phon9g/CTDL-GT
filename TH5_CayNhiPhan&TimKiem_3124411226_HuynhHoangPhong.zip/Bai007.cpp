/*Hãy mô tả ngắn gọn sự giống và khác nhau giữa
hai cấu trúc Cây Nhị Phân tìm kiếm và Danh Sách
Liên Kết Đơn.
Trả lời:
Giống nhau:
• CTDL động.
• Các thao tác cơ bản Thêm, Xóa, Cập Nhật được thực hiện một
cách linh hoạt.

• Khác nhau
• Dữ liệu trên cây NPTK được tổ chức và dslk đơn thì không.
• Chi phí tìm kiếm, thêm trên cây nhanh hơn trên dslk đơn.
*/