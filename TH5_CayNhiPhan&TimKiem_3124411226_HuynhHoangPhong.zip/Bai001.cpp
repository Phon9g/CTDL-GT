/*Cho một cây nhị phân có nút gốc là Root, mỗi nút trong cây chứa một số
nguyên:
a) Viết chương trình tính trung bình cộng các nút trong cây.
b) Viết chương trình tính trung bình cộng các số dương trong cây.
c) Viết chương trình tính trung bình cộng các số âm trong cây.
d) Viết chương trình tính tính tỉ số R=a/b. Với a là tổng các nút có giá trị
dương, b là tổng các nút có giá trị âm.
*/
#include <iostream>

using namespace std;

struct Node {
    int info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;

// Hàm tạo một nút mới
Node* CreateNode(int x) {
    Node* p = new Node;
    if (p == NULL) return NULL;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Hàm thêm một nút vào cây
void InsertNode(TREE &root, int x) {
    if (root == NULL) {
        root = CreateNode(x);
        return;
    }
    if (x < root->info) InsertNode(root->pLeft, x);
    else InsertNode(root->pRight, x);
}

// Nhập cây từ bàn phím
void NhapCay(TREE &root) {
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        cout << "Nhap gia tri thu " << i + 1 << ": ";
        cin >> x;
        InsertNode(root, x);
    }
}

// Viết chương trình tính trung bình cộng các nút trong cây.
int DemNode(TREE root) {
    if (root == NULL) return 0;
    return 1 + DemNode(root->pLeft) + DemNode(root->pRight);
}

int TongNode(TREE root) {
    if (root == NULL) return 0;
    return root->info + TongNode(root->pLeft) + TongNode(root->pRight);
}

float TrungBinhCong(TREE root) {
    int tong = TongNode(root);
    int dem = DemNode(root);
    return (dem == 0) ? 0 : (float)tong / dem;
}

// Viết chương trình tính trung bình cộng các nút dương trong cây.
int DemDuong(TREE root) {
    if (root == NULL) return 0;
    return (root->info > 0 ? 1 : 0) + DemDuong(root->pLeft) + DemDuong(root->pRight);
}

int TongDuong(TREE root) {
    if (root == NULL) return 0;
    return (root->info > 0 ? root->info : 0) + TongDuong(root->pLeft) + TongDuong(root->pRight);
}

float TrungBinhDuong(TREE root) {
    int tong = TongDuong(root);
    int dem = DemDuong(root);
    return (dem == 0) ? 0 : (float)tong / dem;
}

// Viết chương trình tính trung bình cộng các nút âm trong cây.
int DemAm(TREE root) {
    if (root == NULL) return 0;
    return (root->info < 0 ? 1 : 0) + DemAm(root->pLeft) + DemAm(root->pRight);
}

int TongAm(TREE root) {
    if (root == NULL) return 0;
    return (root->info < 0 ? root->info : 0) + TongAm(root->pLeft) + TongAm(root->pRight);
}

float TrungBinhCongAm(TREE root) {
    int tong = TongAm(root);
    int dem = DemAm(root);
    return (dem == 0) ? 0 : (float)tong / dem;
}

// Viết chương trình tính tỉ số R = a / b. Với a là tổng các nút có giá trị dương, b là tổng các nút có giá trị âm.
float TinhTySo(TREE root) {
    int tongDuong = TongDuong(root);
    int tongAm = TongAm(root);
    return (tongAm == 0) ? 0 : (float)tongDuong / tongAm;
}

int main() {
    TREE root = NULL;
    NhapCay(root);
    
    cout << "Trung binh cong cac nut: " << TrungBinhCong(root) << endl;
    cout << "Trung binh cong cac so duong: " << TrungBinhDuong(root) << endl;
    cout << "Trung binh cong cac so am: " << TrungBinhCongAm(root) << endl;
    cout << "Ti so R = a/b: " << TinhTySo(root) << endl;
    
    return 0;
}
/*Nhap so luong phan tu: 4
Nhap gia tri thu 1: 1
Nhap gia tri thu 2: 2
Nhap gia tri thu 3: 3
Nhap gia tri thu 4: 4
Trung binh cong cac nut: 2.5
Trung binh cong cac so duong: 2.5
Trung binh cong cac so am: 0
Ti so R = a/b: 0
*/