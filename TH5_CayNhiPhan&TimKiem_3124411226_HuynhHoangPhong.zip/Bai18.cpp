/* Cho một mảng a gồm n phần tử kiểu số nguyên int. Ta có thể sắp xếp mảng a
bằng cách:
• Từ mảng a, tạo một cây nhị phân tìm kiếm T.
• Duyệt cây T và đưa các nút trở lại mảng a.
• Yêu cầu
a) Cho biết phương pháp duyệt cây T để đưa các nút lên mảng sao cho mảng
được sắp tăng dần.
b) Cho biết cấu trúc cây T.
c) Xây dựng hàm
• Tạo cnp T từ mảng a.
• Duyệt cây để đưa các phần tử trở lại mảng sao cho mảng được sắp thứ tự
tăng dần.
Trả lời 
Câu a: Phương pháp duyệt là LNR.
*/
#include <iostream>

using namespace std;

// Định nghĩa cấu trúc của một nút trong cây nhị phân tìm kiếm (BST)
struct Node {
    int info;         // Giá trị của nút
    Node* pLeft;      // Con trỏ trỏ đến cây con bên trái
    Node* pRight;     // Con trỏ trỏ đến cây con bên phải
};

typedef Node* TREE;  // Định nghĩa kiểu dữ liệu TREE là con trỏ Node

// Hàm khởi tạo cây
void Init(TREE &t) {
    t = NULL;  // Cây ban đầu là rỗng
}

// Hàm tạo một nút mới
Node* GetNode(int x) {
    Node* p = new Node;  // Cấp phát bộ nhớ cho nút mới
    if (p == NULL) return NULL; // Kiểm tra cấp phát bộ nhớ thất bại
    p->info = x;  // Gán giá trị cho nút
    p->pLeft = p->pRight = NULL; // Ban đầu chưa có con trái và con phải
    return p;
}

// Hàm chèn một phần tử vào cây nhị phân tìm kiếm
int InsertNode(TREE &t, int x) {
    if (t) { // Nếu cây không rỗng
        if (t->info == x) return 0; // Tránh chèn trùng giá trị
        if (t->info < x) return InsertNode(t->pRight, x); // Chèn vào cây con bên phải nếu lớn hơn
        return InsertNode(t->pLeft, x);  // Chèn vào cây con bên trái nếu nhỏ hơn
    }
    // Nếu cây rỗng, tạo một nút mới
    t = GetNode(x);
    return (t == NULL) ? -1 : 1; // Kiểm tra xem cấp phát thành công không
}

// Hàm tạo cây nhị phân tìm kiếm từ mảng a
int TaoCay(TREE &t, int a[], int n) {
    Init(t); // Khởi tạo cây
    for (int i = 0; i < n; i++) { // Lặp qua mảng và chèn từng phần tử vào cây
        if (InsertNode(t, a[i]) == -1) return 0; // Nếu chèn thất bại, trả về 0
    }
    return 1; // Thành công
}

// Hàm duyệt cây theo thứ tự LNR (Left - Node - Right) để sắp xếp mảng tăng dần
void LNR(TREE t, int a[], int &n) {
    if (t == NULL) return; // Điều kiện dừng đệ quy
    LNR(t->pLeft, a, n); // Duyệt cây con bên trái
    a[n++] = t->info; // Ghi giá trị vào mảng
    LNR(t->pRight, a, n); // Duyệt cây con bên phải
}

// Hàm sắp xếp mảng bằng cách sử dụng cây nhị phân tìm kiếm
void TreeSort(int a[], int n) {
    TREE t;
    TaoCay(t, a, n); // Tạo cây từ mảng
    int index = 0;
    LNR(t, a, index); // Duyệt cây để lấy lại giá trị đã sắp xếp
}

// Hàm main để kiểm tra chương trình
int main() {
    int a[] = {5, 2, 9, 1, 7, 6, 3};
    int n = sizeof(a) / sizeof(a[0]);
    
    TreeSort(a, n); // Sắp xếp mảng
    
    cout << "Mang sau khi sap xep: ";
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
    
    return 0;
}