/*Hãy viết một hàm tạo danh sách liên kết đơn từ
cây nhị phân tìm kiếm sao cho giá trị các phần tử
trong danh sách có thứ tự giảm dần. Biết nút gốc
của cây là Root.
*/
#include <iostream>

using namespace std;

// Cấu trúc dữ liệu của một nút trong cây nhị phân tìm kiếm (BST)
struct NodeTree {
    int info;
    NodeTree* pLeft;
    NodeTree* pRight;
};
typedef NodeTree* TREE;

// Cấu trúc dữ liệu của một nút trong danh sách liên kết đơn
struct NodeList {
    int info;
    NodeList* pNext;
};
typedef struct NodeList NODELIST;

// Cấu trúc dữ liệu của danh sách liên kết đơn
struct List {
    NODELIST* pHead;
    NODELIST* pTail;
};
typedef struct List LIST;

// Hàm khởi tạo danh sách liên kết đơn
void Init(LIST &l) {
    l.pHead = l.pTail = NULL;
}

// Hàm tạo một nút mới trong danh sách liên kết
NODELIST* GetNode(int x) {
    NODELIST* p = new NODELIST;
    if (p == NULL) return NULL;
    p->info = x;
    p->pNext = NULL;
    return p;
}

// Hàm thêm một nút vào cuối danh sách liên kết
void AddTail(LIST &l, NODELIST* p) {
    if (l.pHead == NULL) {
        l.pHead = l.pTail = p;
    } else {
        l.pTail->pNext = p;
        l.pTail = p;
    }
}

// Hàm duyệt cây theo thứ tự RNL (Right - Node - Left) và thêm vào danh sách
void RNL(TREE Root, LIST &l) {
    if (Root == NULL) return;
    
    RNL(Root->pRight, l); // Duyệt nhánh phải trước
    
    NODELIST* p = GetNode(Root->info); // Tạo nút mới từ giá trị của cây
    if (p != NULL) AddTail(l, p); // Thêm vào danh sách
    
    RNL(Root->pLeft, l); // Duyệt nhánh trái sau
}

// Hàm xây dựng danh sách liên kết từ cây BST theo thứ tự giảm dần
void BuildList(TREE Root, LIST &l) {
    Init(l); // Khởi tạo danh sách
    RNL(Root, l); // Gọi hàm duyệt cây theo RNL để tạo danh sách
}

// Hàm in danh sách liên kết
void PrintList(LIST l) {
    NODELIST* p = l.pHead;
    while (p != NULL) {
        cout << p->info << " -> ";
        p = p->pNext;
    }
    cout << "NULL" << endl;
}

int main() {
    // Ví dụ: Tạo một cây BST đơn giản
    TREE root = new NodeTree{10, NULL, NULL};
    root->pLeft = new NodeTree{5, NULL, NULL};
    root->pRight = new NodeTree{15, NULL, NULL};
    root->pLeft->pLeft = new NodeTree{3, NULL, NULL};
    root->pLeft->pRight = new NodeTree{7, NULL, NULL};
    root->pRight->pLeft = new NodeTree{12, NULL, NULL};
    root->pRight->pRight = new NodeTree{18, NULL, NULL};

    LIST l;
    BuildList(root, l);
    
    cout << "Danh sách liên kết đơn theo thứ tự giảm dần: " << endl;
    PrintList(l);
    
    return 0;
}