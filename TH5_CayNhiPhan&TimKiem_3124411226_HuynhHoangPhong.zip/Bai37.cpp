/* Bài 37:
• Cho một cây nhị phân có nút gốc là Root. Hãy viết hàm kiểm tra xem cây này
có phải là cây cân bằng không? (Giả sử đã có hàm tính chiều cao của nút p
như sau:

int ChieuCao(NODE*p)
• và thông tin tại mỗi nút trong cây là số nguyên).
*/

#include <iostream>
#include <cmath> // Thư viện hỗ trợ hàm abs()

using namespace std;

// Định nghĩa cấu trúc của một nút trong cây nhị phân
struct node {
    int info;          // Giá trị tại nút
    struct node *pLeft;  // Con trái
    struct node *pRight; // Con phải
};

typedef struct node NODE;
typedef NODE* TREE;

// Hàm tìm phần tử lớn nhất trong cây
NODE* LonNhat(TREE t) {
    if (t == NULL) return NULL;
    NODE* lc = t;
    NODE* a = LonNhat(t->pLeft);
    if (a && a->info > lc->info) lc = a;
    NODE* b = LonNhat(t->pRight);
    if (b && b->info > lc->info) lc = b;
    return lc;
}

// Hàm tìm phần tử nhỏ nhất trong cây
NODE* NhoNhat(TREE t) {
    if (t == NULL) return NULL;
    NODE* lc = t;
    NODE* a = NhoNhat(t->pLeft);
    if (a && a->info < lc->info) lc = a;
    NODE* b = NhoNhat(t->pRight);
    if (b && b->info < lc->info) lc = b;
    return lc;
}

// Hàm tính chiều cao của một cây nhị phân
int ChieuCao(TREE t) {
    if (t == NULL) return 0;
    int a = ChieuCao(t->pLeft);
    int b = ChieuCao(t->pRight);
    return max(a, b) + 1;
}

// Hàm kiểm tra cây có cân bằng hay không
int ktCanBang(TREE Root) {
    if (Root == NULL) return 1; // Cây rỗng được coi là cân bằng
    
    // Kiểm tra cây con bên trái và cây con bên phải có cân bằng không
    if (!ktCanBang(Root->pLeft) || !ktCanBang(Root->pRight)) return 0;
    
    // Kiểm tra điều kiện cây tìm kiếm nhị phân (BST)
    NODE* a = LonNhat(Root->pLeft);
    if (a && a->info > Root->info) return 0;
    a = NhoNhat(Root->pRight);
    if (a && a->info < Root->info) return 0;
    
    // Kiểm tra sự chênh lệch chiều cao giữa hai nhánh
    int x = ChieuCao(Root->pLeft);
    int y = ChieuCao(Root->pRight);
    if (abs(x - y) > 1) return 0;
    
    return 1; // Cây cân bằng
}

int main() {
    TREE Root = NULL; // Khởi tạo cây rỗng (cần có thêm phần tạo cây để kiểm tra)
    
    // Gọi hàm kiểm tra cân bằng
    if (ktCanBang(Root)) {
        cout << "Cay can bang." << endl;
    } else {
        cout << "Cay khong can bang." << endl;
    }
    
    return 0;
}