// Bai 2. Giai phuong trinh trung phuong bac 4 
#include <iostream>
#include <cmath>

using namespace std;
int giaiPT(double a, double b, double c, double x1, double x2) {
    double d = b * b - 4 * a * c;
    if (d < 0) {
        x1 = x2 = 0;
        return 0;
    }
    else if (d == 0) {
        x1 = x2 = -b / 2 * a;
        return 1;
    }
    else {
        x1 = (-b + sqrt(d)) / 2 * a;
        x2 = (-b - sqrt(d)) / 2 * a;
        return 2;
    }
}
int main() {
    double a, b, c, x1, x2;
    cout << "Nhap he so a,b,c: ";
    cin >> a >> b >> c;
    if (giaiPT(a, b, c, x1, x2) == 0) {
        cout << "Phuong trinh vo nghiem. ";
    }
    else if (giaiPT(a, b, c, x1, x2) == 1) {
        if (x1 < 0)
            cout << " Phuong trinh vo nghiem. ";
        else if (x1 == 0)
            cout << "Phuong trinh co 1 nghiem phan biet: " << 0;
        else {
            cout << "Phuong trinh co 2 nghiem phan biet:\n ";
            cout << sqrt(x1) << " " << -sqrt(x1) << endl;
        }
    }
    else {
        if (x1 < 0) {
            if (x2 < 0)
                cout << "Phuong trinh vo nghiem";
            else if (x2 == 0)
                cout << "Phuong trinh co 1 nghiem phan biet:" << 0;
            else {
                cout << "Phuong trinh co 2 nghiem phan biet:\n ";
                cout << sqrt(x2) << " " << -sqrt(x2) << endl;
            }
        }
        else if (x1 == 0) {
            if (x2 < 0)
                cout << "Phuong trinh co 1 nghiem phan biet: " << 0;
            else {
                cout << "Phuong trinh co 3 nghiem phan biet: \n ";
                cout << sqrt(x2) << " " << -sqrt(x2) << " " << 0;
            }
        }
        else {
            if (x2 < 0) {
                cout << "Phuong trinh co 2 nghiem phan biet:\n ";
                cout << sqrt(x1) << " " << -sqrt(x1) << endl;
            }
            else if (x2 == 0) {
                cout << "Phuong trinh co 3 nghiem phan biet: \n ";
                cout << sqrt(x1) << " " << -sqrt(x1) << " " << 0 << endl;
            }
            else {
                cout << "Phuong trinh co 4 nghiem: \n";
                cout << sqrt(x1) << " " << -sqrt(x1) << " " << (x2) << " " << -sqrt(x2) << endl;
            }
        }
        return 0;
    }
}