// Bai 1. giai phuong trinh bac 2
#include <iostream> 
#include <cmath>

using namespace std;
int main() {
    double a, b, c, x, x1, x2, d;
    cout << "Nhap he so a,b,c: ";
    cin >> a >> b >> c;
    d = b * b - 4 * a * c;
    // Truong hop khong tinh duoc delta
    if (a == 0) {
        if (b == 0) {
            if (c == 0) {
                cout << "Phuong trinh vo so nghiem";
            }
            else {
                cout << "Phuong trinh vo nghiem";
            }
        }
    }
    else {
        // Truong hop tinh duoc delta 
        if (d < 0) {
            cout << "Phuong trinh vo nghiem" << endl;
        }
        if (d == 0) {
            x = -b / 2 * a;
            cout << "Phuong trinh co nghiem kep la:\n ";
            cout << x << endl;
        }
        if (d > 0) {
            x1 = (-b - sqrt(d)) / 2 * a;
            x2 = (-b + sqrt(d)) / 2 * a;
            cout << "Phuong trinh co 2 nghiem phan biet la:\n ";
            cout << x1 << " " << x2 << endl;
        }
    }
    return 0;
}