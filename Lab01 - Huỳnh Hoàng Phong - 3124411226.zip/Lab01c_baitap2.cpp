#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

#define MAX 20

// C?u tr�c LoaiHoa
struct LoaiHoa {
    char Ten[50];   // T�n lo?i hoa
    int SoLuong;    // S? l??ng t?n kho
    char DVT[10];   // ??n v? t�nh
    float DonGia;   // ??n gi� b�n
};

// C?u tr�c DanhSachLoaiHoa
struct DanhSachLoaiHoa {
    LoaiHoa aHoa[MAX];  // M?ng ch?a t?i ?a 20 lo?i hoa
    int SoLuong;        // S? l??ng lo?i hoa hi?n c�
};

// H�m nh?p danh s�ch c�c lo?i hoa
void NhapDanhSach(DanhSachLoaiHoa& ds) {
    cout << "Nhap so luong loai hoa: ";
    cin >> ds.SoLuong;

    while (ds.SoLuong <= 0 || ds.SoLuong > MAX) {
        cout << "So luong loai hoa khong hop le! Nhap lai: ";
        cin >> ds.SoLuong;
    }

    cin.ignore(); // X�a b? nh? ??m tr??c khi nh?p chu?i
    for (int i = 0; i < ds.SoLuong; i++) {
        cout << "\nNhap thong tin loai hoa thu " << i + 1 << ":\n";
        cout << "Ten loai hoa: ";
        cin.getline(ds.aHoa[i].Ten, 50);

        cout << "So luong: ";
        cin >> ds.aHoa[i].SoLuong;

        cin.ignore(); // X�a b? nh? ??m
        cout << "Don vi tinh: ";
        cin.getline(ds.aHoa[i].DVT, 10);

        cout << "Don gia: ";
        cin >> ds.aHoa[i].DonGia;
        cin.ignore(); // X�a b? nh? ??m
    }
}

// H�m xu?t danh s�ch hoa ra m�n h�nh
void XuatDanhSach(DanhSachLoaiHoa ds) {
    cout << "\nDanh sach loai hoa trong cua hang:\n";
    cout << left << setw(20) << "Ten loai"
        << setw(12) << "So luong"
        << setw(10) << "DVT"
        << setw(12) << "Don gia" << endl;
    cout << "-------------------------------------------------\n";

    for (int i = 0; i < ds.SoLuong; i++) {
        cout << left << setw(20) << ds.aHoa[i].Ten
            << setw(12) << ds.aHoa[i].SoLuong
            << setw(10) << ds.aHoa[i].DVT
            << setw(12) << ds.aHoa[i].DonGia << endl;
    }
}

// H�m t�m lo?i hoa theo t�n lo?i
int TimLoaiHoa(DanhSachLoaiHoa ds, char* tenloai) {
    for (int i = 0; i < ds.SoLuong; i++) {
        if (strcmp(ds.aHoa[i].Ten, tenloai) == 0) {
            return i; // Tr? v? v? tr� n?u t�m th?y
        }
    }
    return -1; // Kh�ng t�m th?y
}

// H�m x? l� b�n hoa cho kh�ch h�ng
void XuLyBanHoa(DanhSachLoaiHoa& ds, char* tenloai, int soluong) {
    int vitri = TimLoaiHoa(ds, tenloai);

    if (vitri == -1) {
        cout << "Loai hoa '" << tenloai << "' khong ton tai trong cua hang.\n";
        return;
    }

    if (ds.aHoa[vitri].SoLuong < soluong) {
        cout << "Khong du so luong '" << tenloai << "' de ban. Chi con "
            << ds.aHoa[vitri].SoLuong << " " << ds.aHoa[vitri].DVT << ".\n";
        return;
    }

    // T�nh t?ng ti?n v� gi?m s? l??ng hoa trong kho
    float tongTien = soluong * ds.aHoa[vitri].DonGia;
    ds.aHoa[vitri].SoLuong -= soluong;

    cout << "Ban thanh cong " << soluong << " " << ds.aHoa[vitri].DVT
        << " loai hoa '" << tenloai << "'.\n";
    cout << "Tong tien: " << tongTien << " VND\n";
}

int main() {
    DanhSachLoaiHoa ds;
    char tenloai[50];
    int soluong;

    // Nh?p danh s�ch c�c lo?i hoa
    NhapDanhSach(ds);

    // Xu?t danh s�ch lo?i hoa
    XuatDanhSach(ds);

    // Kh�ch h�ng mua hoa
    cout << "\nNhap ten loai hoa can mua: ";
    cin.getline(tenloai, 50);
    cout << "Nhap so luong can mua: ";
    cin >> soluong;

    // X? l� b�n hoa
    XuLyBanHoa(ds, tenloai, soluong);

    // Xu?t danh s�ch sau khi b�n
    cout << "\nDanh sach loai hoa sau khi ban:\n";
    XuatDanhSach(ds);

    return 0;
}
