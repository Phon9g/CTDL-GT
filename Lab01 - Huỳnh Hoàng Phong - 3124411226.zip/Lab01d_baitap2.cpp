#include <iostream>
#include <cstring>

using namespace std;

// H�m x�a k� t? t?i v? tr� k
void XoaKyTu(char* s, int k) {
    int len = strlen(s);

    // Ki?m tra n?u k kh�ng h?p l?
    if (k < 0 || k >= len) {
        cout << "Vi tri khong hop le!" << endl;
        return;
    }

    // D?ch c�c k� t? sang tr�i t? v? tr� k
    for (char* p = s + k; *p != '\0'; p++) {
        *p = *(p + 1);
    }
}

int main() {
    char s[1001]; // Chu?i t?i ?a 1000 k� t? + 1 k� t? null
    int k;

    cout << "Moi ban nhap chuoi s: ";
    cin.getline(s, 1001); // Nh?p chu?i

    cout << "Moi ban nhap vi tri can xoa: ";
    cin >> k;

    // X�a k� t? t?i v? tr� k
    XoaKyTu(s, k);

    cout << "Chuoi sau khi xoa ky tu tai vi tri " << k << ": " << s << endl;

    return 0;
}
