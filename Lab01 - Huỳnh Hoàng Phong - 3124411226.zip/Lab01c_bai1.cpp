﻿#include <stdio.h>
#include <math.h>
/* Khai bao cao truc PhanSo */
typedef struct tagPhanSo
{
	int tuSo;
	int mauSo;
} PhanSo;
/* Dinh nghia cac phuong thuc cho PhanSo */
/*
Nhap phan so tu ban phim
+ Vao: ban phim, info (thong bao nhap phan so)
+ Ra : ps
+ Vi du:
* PhanSo ps = {0,0};
* NhapPhanSo("Moi ban nhap phan so 1: ",ps);
- Moi ban nhap phan so 1: 1 2
--> ps = {1,2}
*/
void NhapPhanSo(const char* info, PhanSo& ps);
/*
Xuat phan so ra man hinh
+ Vao: ps, info (chuoi xuat phan so)
+ Ra : man hinh
+ Vi du:
* PhanSo ps = {1,2}
* XuatPhanSo(ps);
- Man hinh = [1/2]
*/
void XuatPhanSo(PhanSo ps);
/*
Rut gon phan so
+ Vao: ps
+ Ra : ps (phan so sau khi rut gon)
+ Vi du:
* PhanSo ps = {2,6}
* RutGonPhanSo(ps);
--> ps = {1,3}
*/
void RutGonPhanSo(PhanSo& ps);
/*
So sanh hai phan so
+ Vao: p1, p2
+ Ra : ret = -1 (p1<p2), 0 (p1=p2), 1 (p1>p2)
+ Vi du:
* PhanSo p1 = {2,6}, p2 = {2,4};
* int ret = SoSanhPhanSo(p1,p2);
--> ret = -1
*/
int SoSanhPhanSo(PhanSo p1, PhanSo p2);
/*
Cong hai phan so
+ Vao: p1, p2
+ Ra : pret
+ Vi Du:
* PhanSo p1 = {2,4}, p2 = {2,6}, pret;
* CongHaiPhanSo(p1,p2,pret);
--> pret = {5,6}
*/
void CongPhanSo(PhanSo p1, PhanSo p2, PhanSo& pret)
{
	pret.tuSo = p1.tuSo * p2.mauSo + p1.mauSo * p2.tuSo;
	pret.mauSo = p1.mauSo * p2.mauSo;
	RutGonPhanSo(pret);
}// CongPhanSo
int main()
{
	PhanSo p1, p2;
	NhapPhanSo("Moi ban nhap phan so 1: ", p1);
	NhapPhanSo("Moi ban nhap phan so 2: ", p2);
	RutGonPhanSo(p1); RutGonPhanSo(p2);
	printf("+ Rut gon: ");
	XuatPhanSo(p1); printf(" ");
	XuatPhanSo(p2); printf("\n");
	char aDau[3] = { '<','=','>' }; // aDau[ret+1]
	int ret = SoSanhPhanSo(p1, p2);
	printf("+ So sanh: ");
	XuatPhanSo(p1); printf("%c", aDau[ret + 1]);
	XuatPhanSo(p2); printf("\n");

		PhanSo pret;
	CongPhanSo(p1, p2, pret);
	printf("+ Cong: ");
	XuatPhanSo(p1); printf("+");
	XuatPhanSo(p2); printf("=");
	XuatPhanSo(pret); printf("\n");
	return 0;
}// main
void NhapPhanSo(const char* info, PhanSo& ps)
{
	printf("%s", info);
	scanf("%d%d", &ps.tuSo, &ps.mauSo);
}// NhapPhanSo
void XuatPhanSo(PhanSo ps)
{
	printf("[%d/%d]", ps.tuSo, ps.mauSo);
}// XuatPhanSo
void RutGonPhanSo(PhanSo& ps)
{
	int ucln, a, b, tmp;
	// Di tim UCLN cua tuSo va mauSo
	a = ps.tuSo;
	b = ps.mauSo;
	while (b != 0)
	{
		tmp = a;
		a = b;
		b = tmp % a;
	}// while
	ucln = a;
	// Rut gon tuSo va mauSo
	ps.tuSo = ps.tuSo / ucln;
	ps.mauSo = ps.mauSo / ucln;
}// RutGonPhanSo
int SoSanhPhanSo(PhanSo p1, PhanSo p2)
{
	int ret;
	// chuan hoa phan so de mauSo > 0
	// (tranh qui dong mau so voi mauSo<0 --> se bi dao dau so sanh)
	p1.tuSo = p1.tuSo * p1.mauSo / abs(p1.mauSo);
	p1.mauSo = abs(p1.mauSo);
	p2.tuSo = p2.tuSo * p2.mauSo / abs(p2.mauSo);
	p2.mauSo = abs(p2.mauSo);
	// qui dong mau so
	int vp1 = p1.tuSo * p2.mauSo;
	int vp2 = p2.tuSo * p1.mauSo;
	if (vp1 > vp2)
		ret = 1;
	else if (vp1 == vp2)

		ret = 0;
	else
		ret = -1;
	return ret;
}// SoSanhPhanSo
Bài 2. Cho thông tin một quyển sách gồm : Mã sách(tối đa 10 ký tự), Tên sách(tối đa 20 ký tự), Giá
(số nguyên).Viết các hàm nhập n(
	n 100
) quyển sách và tìm quyển sách có mã cho trước.

Chương trình
#include <stdio.h>
#include <conio.h>
#include <string.h>
#define MAX 100
typedef struct SachTag
{
	char maSach[11];
	char tenSach[21];
	int gia;
} Sach;
void Nhap1QuyenSach(Sach& s)
{
	printf("Ma sach: "); gets(s.maSach);
	printf("Ten sach: "); gets(s.tenSach);
	printf("Gia: "); scanf("%d", &s.gia);
	flushall();
}
void Xuat1QuyenSach(Sach s)
{
	printf("Ma sach: %s \n", s.maSach);
	printf("Ten sach: %s \n", s.tenSach);
	printf("Gia: %d \n", s.gia);
}
void NhapMangSach(Sach a[], int& n)
{
	printf("Nhap so luong sach: ");
	scanf("%d", &n);
	int i;
	for (i = 0; i < n; i++)
	{
		printf("Nhap quyen sach thu %d: \n", i);
		Nhap1QuyenSach(a[i]);
	}
}
int TimSachTheoMa(Sach a[], int n, char ma[], Sach& kq)
{
	int timThay = 0;
	int i = 0;
	while (i < n && timThay == 0)
	{
		if (strcmp(ma, a[i].maSach) == 0)
		{
			kq = a[i];

			Cấu trúc

				Trang 5

				timThay = 1;
		}
		i++;
	}
	return timThay;
}
int main(void)
{
	Sach a[MAX];
	int n;
	NhapMangSach(a, n);
	char ma[11];
	printf("Nhap ma sach muon tim: ");
	gets(ma);
	Sach kq;
	int timThay;
	timThay = TimSachTheoMa(a, n, ma, kq);
	if (timThay == 1)
	{
		printf("Quyen sach tim duoc la: \n");
		Xuat1QuyenSach(kq);
	}
	else
		printf("Khong tim thay quyen sach co ma da cho");
	return 0;
}