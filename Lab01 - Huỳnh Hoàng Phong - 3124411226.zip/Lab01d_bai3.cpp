#include <iostream>
#include <cstring>

using namespace std;

void DemSoTu(char* s) {
    int len = strlen(s);
    int soTu = 0;
    char* pDau = nullptr, * pCuoi = nullptr;

    for (int i = 0; i < len; i++) {
        // X�c ??nh k� t? ??u ti�n c?a t?
        if ((i == 0 || s[i - 1] == ' ') && s[i] != ' ') {
            pDau = &s[i];
        }

        // X�c ??nh k� t? cu?i c?a t?
        if ((i == len - 1 || s[i + 1] == ' ') && s[i] != ' ') {
            pCuoi = &s[i];
            soTu++;

            // In t? v?a t�m ???c
            cout << "\"";
            for (char* p = pDau; p <= pCuoi; p++) {
                cout << *p;
            }
            cout << "\" ";

            pDau = nullptr; // Reset con tr? ??u t?
        }
    }

    cout << "\nChuoi co " << soTu << " tu.\n";
}

int main() {
    char s[1001]; // Gi?i h?n 1000 k� t? + 1 k� t? null
    cout << "Moi ban nhap chuoi s: ";
    cin.getline(s, 1001); // ??c c? d�ng bao g?m d?u c�ch

    cout << "Cac tu trong chuoi: ";
    DemSoTu(s);

    return 0;
}
