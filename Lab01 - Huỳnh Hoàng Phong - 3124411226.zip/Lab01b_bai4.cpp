#include <iostream>

using namespace std;

// H�m ki?m tra t�nh ?an d?u
bool KiemTraDanDau(float* a, int n) {
    for (int i = 1; i < n; i++) {
        if ((a[i] * a[i - 1]) >= 0) {
            return false; // N?u hai s? c�ng d?u, kh�ng ?an d?u
        }
    }
    return true;
}

// H�m ki?m tra t�nh ??n ?i?u
bool KiemTraDonDieu(float* a, int n) {
    bool tang = true, giam = true;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[i - 1]) tang = false; // Kh�ng t?ng
        if (a[i] > a[i - 1]) giam = false; // Kh�ng gi?m
    }
    return tang || giam;
}

// H�m ki?m tra t�nh ??i x?ng
bool KiemTraDoiXung(float* a, int n) {
    for (int i = 0; i < n / 2; i++) {
        if (a[i] != a[n - 1 - i]) {
            return false;
        }
    }
    return true;
}

int main() {
    int n;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> n;

    if (n <= 0 || n > 100) {
        cout << "So luong phan tu khong hop le!" << endl;
        return 1;
    }

    float* a = new float[n]; // C?p ph�t ??ng m?ng

    // Nh?p d�y s?
    for (int i = 0; i < n; i++) {
        cout << "Phan tu " << i << ": ";
        cin >> a[i];
    }

    // Ki?m tra t�nh ch?t
    if (KiemTraDanDau(a, n)) {
        cout << "+ Day co tinh chat dan dau" << endl;
    }
    else {
        cout << "+ Day khong co tinh chat dan dau" << endl;
    }

    if (KiemTraDonDieu(a, n)) {
        cout << "+ Day co tinh chat don dieu" << endl;
    }
    else {
        cout << "+ Day khong co tinh chat don dieu" << endl;
    }

    if (KiemTraDoiXung(a, n)) {
        cout << "+ Day co tinh chat doi xung" << endl;
    }
    else {
        cout << "+ Day khong co tinh chat doi xung" << endl;
    }

    delete[] a; // Gi?i ph�ng b? nh?
    return 0;
}
