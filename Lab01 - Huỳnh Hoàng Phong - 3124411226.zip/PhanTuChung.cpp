﻿// Bai 3. Tim phan tu chung
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    // Nhập số lượng phần tử của ba dãy
    int nx, ny, nz;
    cin >> nx;
    int x[1000];
    for (int i = 0; i < nx; i++) {
        cin >> x[i];
    }
    cin >> ny;
    int y[1000];
    for (int i = 0; i < ny; i++) {
        cin >> y[i];
    }
    cin >> nz;
    int z[1000];
    for (int i = 0; i < nz; i++) {
        cin >> z[i];
    }
    // Thuật toán sắp xếp nhanh 
    sort(x, x + nx);
    sort(y, y + ny);
    sort(z, z + nz);
    // Dùng ba con trỏ để tìm phần tử chung
    int i = 0, j = 0, k = 0;
    int ketqua[1000]; // Lưu các phần tử chung
    int dem = 0;
    while (i < nx && j < ny && k < nz) {
        if (x[i] == y[j] && y[j] == z[k]) {
            // Nếu có phần tử chung thì lưu vào 
            if (dem == 0 || ketqua[dem - 1] != x[i]) {
                ketqua[dem++] = x[i];
            }
            i++; j++; k++;
        }
        else if (x[i] < y[j]) {
            i++;
        }
        else if (y[j] < z[k]) {
            j++;
        }
        else {
            k++;
        }
    }
    // Kết quả
    cout << dem << endl;
    for (int idx = 0; idx < dem; idx++) {
        cout << ketqua[idx] << " ";
    }
    return 0;
}