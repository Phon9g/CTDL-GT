#include <iostream>

using namespace std;

// H�m ki?m tra k� t? c� ph?i nguy�n �m kh�ng
bool LaNguyenAm(char* c) {
    char x = tolower(*c); // Chuy?n v? ch? th??ng ?? ki?m tra
    return (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u');
}

int main() {
    int n;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> n;

    // C?p ph�t b? nh? ??ng cho m?ng a
    char* a = new char[n];

    // Nh?p m?ng k� t? s? d?ng con tr?
    for (char* p = a; p < a + n; p++) {
        cout << "Phan tu " << (p - a) << ": ";
        cin >> *p;
    }

    // C?p ph�t b? nh? ??ng cho m?ng b
    char* b = new char[n];
    int count = 0;

    // Duy?t m?ng a b?ng con tr? v� l?u nguy�n �m v�o b
    for (char* p = a; p < a + n; p++) {
        if (LaNguyenAm(p)) {
            *(b + count) = *p;
            count++;
        }
    }

    // Xu?t k?t qu?
    if (count == 0) {
        cout << "+ Khong co ky tu nguyen am trong day" << endl;
    }
    else {
        cout << "+ Day ky tu nguyen am: ";
        for (char* p = b; p < b + count; p++) {
            cout << *p << " ";
        }
        cout << endl;
    }

    // Gi?i ph�ng b? nh? ??ng
    delete[] a;
    delete[] b;

    return 0;
}
