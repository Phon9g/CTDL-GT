#include <iostream>
#include <cstring>

using namespace std;

// H�m ch�n k� t? v�o v? tr� k
void ChenKyTu(char* s, int k, char c) {
    int len = strlen(s);

    // Ki?m tra n?u k kh�ng h?p l?
    if (k < 0 || k > len) {
        cout << "Vi tri khong hop le!" << endl;
        return;
    }

    // D?ch c�c k� t? sang ph?i ?? t?o kho?ng tr?ng t?i v? tr� k
    for (char* p = s + len; p >= s + k; p--) {
        *(p + 1) = *p;
    }

    // G�n k� t? m?i v�o v? tr� k
    *(s + k) = c;
}

int main() {
    char s[1002]; // Chu?i t?i ?a 1000 k� t? + 1 k� t? null + 1 k� t? ch�n v�o
    int k;
    char c;

    cout << "Moi ban nhap chuoi s: ";
    cin.getline(s, 1001); // Nh?p chu?i

    cout << "Moi ban nhap vi tri can chen: ";
    cin >> k;

    cout << "Moi ban nhap ky tu chen: ";
    cin >> c;

    // Ch�n k� t? c v�o v? tr� k
    ChenKyTu(s, k, c);

    cout << "Chuoi sau khi them ky tu \"" << c << "\" vao vi tri " << k << ": " << s << endl;

    return 0;
}
