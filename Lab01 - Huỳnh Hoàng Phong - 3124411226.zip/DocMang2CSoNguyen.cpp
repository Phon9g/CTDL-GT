#include <iostream>
#include <fstream>

using namespace std;

void DocMang2CSoNguyen(const char* filename) {
    ifstream file(filename); // M? file ?? ??c
    if (!file) {
        cout << "Khong the mo file!" << endl;
        return;
    }

    int n, m;
    file >> n >> m; // ??c s? d�ng v� s? c?t

    // C?p ph�t m?ng ??ng 2 chi?u
    int** arr = new int* [n];
    for (int i = 0; i < n; i++) {
        arr[i] = new int[m];
    }

    // ??c d? li?u t? file v�o m?ng
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            file >> arr[i][j];
        }
    }

    file.close(); // ?�ng file

    // Xu?t m?ng ra m�n h�nh
    cout << "Mang 2 chieu doc tu file:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    // Gi?i ph�ng b? nh?
    for (int i = 0; i < n; i++) {
        delete[] arr[i];
    }
    delete[] arr;
}

int main() {
    DocMang2CSoNguyen("MangSo.inp");
    return 0;
}
