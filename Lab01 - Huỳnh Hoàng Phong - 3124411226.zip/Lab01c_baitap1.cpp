#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

#define MAX 100

// C?u tr�c NhanVien
struct NhanVien {
    char MaSo[11];
    char Ho[11];
    char Ten[51];
    int Phai; // 0: N?, 1: Nam
    int ThamNien;
};

// C?u tr�c PhongBan
struct PhongBan {
    NhanVien aNhanVien[MAX];
    int SoLuong;
};

// H�m nh?p danh s�ch nh�n vi�n cho ph�ng ban c� r�ng bu?c d? li?u
void NhapPhongBan(PhongBan& pb) {
    cout << "Nhap so luong nhan vien: ";
    cin >> pb.SoLuong;

    while (pb.SoLuong <= 0 || pb.SoLuong > MAX) {
        cout << "So luong nhan vien khong hop le! Nhap lai: ";
        cin >> pb.SoLuong;
    }

    cin.ignore();
    for (int i = 0; i < pb.SoLuong; i++) {
        cout << "\nNhap thong tin nhan vien thu " << i + 1 << ":\n";
        cout << "Ma so: ";
        cin.getline(pb.aNhanVien[i].MaSo, 11);

        cout << "Ho: ";
        cin.getline(pb.aNhanVien[i].Ho, 11);

        cout << "Ten: ";
        cin.getline(pb.aNhanVien[i].Ten, 51);

        cout << "Phai (0 - Nu, 1 - Nam): ";
        cin >> pb.aNhanVien[i].Phai;
        while (pb.aNhanVien[i].Phai != 0 && pb.aNhanVien[i].Phai != 1) {
            cout << "Phai khong hop le! Nhap lai (0 - Nu, 1 - Nam): ";
            cin >> pb.aNhanVien[i].Phai;
        }

        cout << "Tham nien (>=0): ";
        cin >> pb.aNhanVien[i].ThamNien;
        while (pb.aNhanVien[i].ThamNien < 0) {
            cout << "Tham nien khong hop le! Nhap lai: ";
            cin >> pb.aNhanVien[i].ThamNien;
        }

        cin.ignore(); // X�a b? nh? ??m tr??c khi nh?p chu?i ti?p theo
    }
}

// H�m xu?t th�ng tin ph�ng ban ra m�n h�nh
void XuatPhongBan(PhongBan pb) {
    cout << "\nDanh sach nhan vien:\n";
    cout << left << setw(12) << "Ma so"
        << setw(12) << "Ho"
        << setw(20) << "Ten"
        << setw(6) << "Phai"
        << setw(10) << "Tham nien" << endl;
    cout << "----------------------------------------------------\n";

    for (int i = 0; i < pb.SoLuong; i++) {
        cout << left << setw(12) << pb.aNhanVien[i].MaSo
            << setw(12) << pb.aNhanVien[i].Ho
            << setw(20) << pb.aNhanVien[i].Ten
            << setw(6) << (pb.aNhanVien[i].Phai == 1 ? "Nam" : "Nu")
            << setw(10) << pb.aNhanVien[i].ThamNien << endl;
    }
}

// H�m ??m s? s? nam, n? trong ph�ng ban
void DemSiSo(PhongBan pb, int& soNam, int& soNu) {
    soNam = soNu = 0;
    for (int i = 0; i < pb.SoLuong; i++) {
        if (pb.aNhanVien[i].Phai == 1)
            soNam++;
        else
            soNu++;
    }
}

// H�m s?p x?p danh s�ch nh�n vi�n t?ng d?n theo th�m ni�n (Bubble Sort)
void SapXepTangTheoThamNien(PhongBan& pb) {
    for (int i = 0; i < pb.SoLuong - 1; i++) {
        for (int j = 0; j < pb.SoLuong - i - 1; j++) {
            if (pb.aNhanVien[j].ThamNien > pb.aNhanVien[j + 1].ThamNien) {
                swap(pb.aNhanVien[j], pb.aNhanVien[j + 1]);
            }
        }
    }
}

int main() {
    PhongBan pb;
    int soNam, soNu;

    // Nh?p danh s�ch nh�n vi�n
    NhapPhongBan(pb);

    // Xu?t danh s�ch nh�n vi�n ban ??u
    XuatPhongBan(pb);

    // ??m s? l??ng nam, n?
    DemSiSo(pb, soNam, soNu);
    cout << "\nSo luong nam: " << soNam << endl;
    cout << "So luong nu: " << soNu << endl;

    // S?p x?p danh s�ch nh�n vi�n theo th�m ni�n v� xu?t k?t qu?
    SapXepTangTheoThamNien(pb);
    cout << "\nDanh sach nhan vien sau khi sap xep theo tham nien:\n";
    XuatPhongBan(pb);

    return 0;
}
