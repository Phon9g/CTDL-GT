#include <iostream>
#include <cmath>

using namespace std;

void KiemTraSoChinhPhuong(int* n) {
    int m = sqrt(*n); 
    if (m * m == *n) {
        cout << "So " << *n << " la so chinh phuong." << endl;
    }
    else {
        cout << "So " << *n << " khong phai la so chinh phuong." << endl;
    }
}

int main() {
    int* n = new int; 

   
    cout << "Moi ban nhap so nguyen n: ";
    cin >> *n;

    
    KiemTraSoChinhPhuong(n);

 
    delete n;

    return 0;
}
