#include <stdio.h>
#define FI "Data.inp"
void InputData(int& amp; n)
{
	FILE* fi;
	fi = fopen(FI, &quot; rt & quot;);
	if (fi == NULL)
	{
		printf(&quot; Khong the doc file & quot;);
		return;
	}
	fscanf(f, &quot; % d & quot; , &amp; n);
	fclose(fi);
}
int main()
{
	int n;
	InputData(n);
	printf(&quot; n = % d & quot; , n);
	return 0;
}