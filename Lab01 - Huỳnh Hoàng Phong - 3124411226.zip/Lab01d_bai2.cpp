#include <iostream>
#include <cstring>

using namespace std;

bool KiemTraDoiXung(char* s) {
    char* pDau = s;                     // Con tr? tr? ??n k� t? ??u ti�n
    char* pCuoi = s + strlen(s) - 1;    // Con tr? tr? ??n k� t? cu?i c�ng

    while (pDau < pCuoi) {
        if (*pDau != *pCuoi) {
            return false;  // N?u c� k� t? kh�ng kh?p, chu?i kh�ng ??i x?ng
        }
        pDau++;
        pCuoi--;
    }
    return true;  // N?u to�n b? chu?i ??u kh?p, chu?i ??i x?ng
}

int main() {
    char s[1001]; // Gi?i h?n 1000 k� t? + 1 k� t? null
    cout << "Moi ban nhap chuoi s: ";
    cin.getline(s, 1001); // ??c c? d�ng bao g?m d?u c�ch

    if (KiemTraDoiXung(s)) {
        cout << "Chuoi \"" << s << "\" la doi xung.\n";
    }
    else {
        cout << "Chuoi \"" << s << "\" khong la doi xung.\n";
    }

    return 0;
}
