#include <stdio.h>
#include <math.h>

#define MAX_N 10000

// H�m ki?m tra s? nguy�n t?
int laSoNguyenTo(int n) {
    if (n < 2) return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

int main() {
    FILE* fileIn = fopen("NT.INP", "r");  // M? file ?? ??c
    FILE* fileOut = fopen("NT.OUT", "w"); // M? file ?? ghi

    if (fileIn == NULL || fileOut == NULL) {
        printf("Loi: Khong the mo file!\n");
        return 1;
    }

    int n, a[MAX_N], b[MAX_N], m = 0;

    // ??c s? l??ng ph?n t?
    fscanf(fileIn, "%d", &n);

    // ??c c�c s? nguy�n v� ki?m tra nguy�n t?
    for (int i = 0; i < n; i++) {
        fscanf(fileIn, "%d", &a[i]);
        if (laSoNguyenTo(a[i])) {
            b[m++] = a[i]; // L?u v�o m?ng s? nguy�n t?
        }
    }

    fclose(fileIn); // ?�ng file ??u v�o

    // Ghi s? l??ng s? nguy�n t? v�o file ??u ra
    fprintf(fileOut, "%d\n", m);

    // Ghi c�c s? nguy�n t? ra file
    for (int i = 0; i < m; i++) {
        fprintf(fileOut, "%d ", b[i]);
    }

    fclose(fileOut); // ?�ng file ??u ra

    printf("Ket qua da duoc ghi vao NT.OUT.\n");
    return 0;
}
