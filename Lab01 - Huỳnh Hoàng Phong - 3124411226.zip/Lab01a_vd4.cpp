﻿#include <stdio.h>
#include <stdlib.h>

#define MAX 100 // Số lượng phần tử tối đa của dãy

/*
Nhập dãy số nguyên từ bàn phím
+ Vào: bàn phím
+ Ra : (*a), n
+ Ví dụ: (*a) = {1,2,3}, n = 3
*/
void NhapMang(int*& a, int& n) // Truyền tham biến
{
    printf("Moi ban nhap so luong phan tu: "); // Nhập n
    scanf("%d", &n); // Lỗi ở đây: cần truyền địa chỉ của n

    a = new int[n]; // Cấp phát mảng a có n phần tử
    for (int i = 0; i < n; i++) // Duyệt từ vị trí 0 đến n-1
    {
        printf("Phan tu %d: ", i);
        scanf("%d", &a[i]); // Nhập phần tử thứ a[i]
    }
}

void NhapMang(int** a, int* n) // Truyền tham chiếu
{
    printf("Moi ban nhap so luong phan tu: "); // Nhập (*n)
    scanf("%d", n);

    (*a) = new int[(*n)]; // Cấp phát mảng (*a) có (*n) phần tử
    for (int i = 0; i < (*n); i++) // Duyệt từ vị trí 0 đến (*n)-1
    {
        printf("Phan tu %d: ", i);
        scanf("%d", &(*a)[i]); // Nhập phần tử thứ (*a)[i]
    }
}

/*
Xuất dãy số nguyên ra màn hình
+ Vào: (*a), n
+ Ra : màn hình
+ Ví dụ: *a = {2,5,3}, n = 3
=> màn hình = 2 5 3
*/
void XuatMang(int* a, int n) // Truyền tham trị
{
    printf("Day so co %d phan tu: ", n); // Xuất số lượng phần tử
    for (int i = 0; i < n; i++) // Duyệt từ vị trí 0 đến n-1
    {
        printf("%d ", a[i]); // Xuất a[i]
    }
    printf("\n"); // Xuống dòng
}

// Đổi các giá trị chẵn thành số 0
void DoiChan(int* a, int n)
{
    for (int i = 0; i < n; i++)
    {
        if (a[i] % 2 == 0)
        {
            a[i] = 0;
        }
    }
}

int main()
{
    /* Khai báo biến */
    int* b = NULL, k = 0;

    /* Nhập dữ liệu */
    NhapMang(&b, &k);

    /* Xuất dữ liệu */
    printf("Mang vua nhap:\n");
    XuatMang(b, k);

    /* Đổi số chẵn thành 0 */
    DoiChan(b, k);
    printf("* Doi gia tri chan thanh cac so 0:\n");
    XuatMang(b, k);

    /* Giải phóng bộ nhớ */
    if (b != NULL) delete[] b;

    return 0;
}
