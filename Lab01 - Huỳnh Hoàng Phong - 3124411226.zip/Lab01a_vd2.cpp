﻿#include <stdio.h>

// [1] Truyền tham trị 
void HoanVi_ThamTri(int a, int b)
{
    int tmp = a;
    a = b;
    b = tmp;
}

// [2] Truyền tham biến 
void HoanVi_ThamBien(int& a, int& b)
{
    int tmp = a;
    a = b;
    b = tmp;
}

// [3] Truyền tham chiếu bằng con trỏ 
void HoanVi_ConTro(int* a, int* b)
{
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

int main()
{
    int x = 5, y = 10;

    // [1] Truyền tham trị
    printf("Truoc HoanVi_ThamTri: x = %d, y = %d\n", x, y);
    HoanVi_ThamTri(x, y);
    printf("Sau HoanVi_ThamTri: x = %d, y = %d (KHONG thay doi)\n\n", x, y);

    // [2] Truyền tham biến (C++)
    printf("Truoc HoanVi_ThamBien: x = %d, y = %d\n", x, y);
    HoanVi_ThamBien(x, y);
    printf("Sau HoanVi_ThamBien: x = %d, y = %d (Da thay doi)\n\n", x, y);

    // [3] Truyền tham chiếu bằng con trỏ
    printf("Truoc HoanVi_ConTro: x = %d, y = %d\n", x, y);
    HoanVi_ConTro(&x, &y);
    printf("Sau HoanVi_ConTro: x = %d, y = %d (Da thay doi)\n\n", x, y);

    // [4] Biến tham chiếu (con trỏ)
    int* ptr = &x; // ptr lưu địa chỉ của x
    printf("x: Addr = %p, Val = %d\n", (void*)&x, x);
    printf("ptr: Addr = %p, Val (dia chi cua x) = %p, *ptr = %d\n", (void*)&ptr, (void*)ptr, *ptr);

    return 0;
}
