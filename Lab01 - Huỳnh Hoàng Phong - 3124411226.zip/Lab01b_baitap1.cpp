#include <iostream>
#include <cmath>

using namespace std;

// H�m gi?i ph??ng tr�nh b?c hai
void GiaiPTBacHai(float* a, float* b, float* c, float* x1, float* x2, int* soNghiem) {
    if (*a == 0) {
        if (*b == 0) {
            *soNghiem = (*c == 0) ? -1 : 0; // -1: v� s? nghi?m, 0: v� nghi?m
        }
        else {
            *soNghiem = 1;
            *x1 = -(*c) / (*b);
        }
    }
    else {
        float delta = (*b) * (*b) - 4 * (*a) * (*c);
        if (delta < 0) {
            *soNghiem = 0; // V� nghi?m
        }
        else if (delta == 0) {
            *soNghiem = 1; // Nghi?m k�p
            *x1 = -(*b) / (2 * (*a));
        }
        else {
            *soNghiem = 2; // Hai nghi?m ph�n bi?t
            *x1 = (-(*b) + sqrt(delta)) / (2 * (*a));
            *x2 = (-(*b) - sqrt(delta)) / (2 * (*a));
        }
    }
}

int main() {
    float a, b, c;
    cout << "Moi ban nhap he so a, b, c: ";
    cin >> a >> b >> c;

    float x1, x2;
    int soNghiem;

    // G?i h�m gi?i ph??ng tr�nh
    GiaiPTBacHai(&a, &b, &c, &x1, &x2, &soNghiem);

    // Xu?t k?t qu?
    if (soNghiem == -1) {
        cout << "Phuong trinh co vo so nghiem." << endl;
    }
    else if (soNghiem == 0) {
        cout << "Phuong trinh vo nghiem." << endl;
    }
    else if (soNghiem == 1) {
        cout << "Phuong trinh co 1 nghiem kep x = " << x1 << endl;
    }
    else {
        cout << "Phuong trinh co 2 nghiem phan biet: " << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    }

    return 0;
}
