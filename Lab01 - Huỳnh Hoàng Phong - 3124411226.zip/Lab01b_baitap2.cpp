#include <iostream>

using namespace std;

// H�m ki?m tra t�nh ch?n l? xen k?
bool KiemTraChanLeXenKe(int* a, int n) {
    for (int i = 1; i < n; i++) {
        if ((a[i] % 2) == (a[i - 1] % 2)) { // N?u 2 s? li�n ti?p c�ng ch?n ho?c c�ng l?
            return false;
        }
    }
    return true;
}

// H�m ki?m tra t�nh to�n ch?n
bool KiemTraToanChan(int* a, int n) {
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 != 0) { // N?u g?p s? l?
            return false;
        }
    }
    return true;
}

int main() {
    int n;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> n;

    // C?p ph�t m?ng ??ng
    int* a = new int[n];

    // Nh?p m?ng
    for (int i = 0; i < n; i++) {
        cout << "Phan tu " << i << ": ";
        cin >> *(a + i);
    }

    // Ki?m tra v� xu?t k?t qu?
    if (KiemTraChanLeXenKe(a, n)) {
        cout << "+ Day co tinh chat chan le" << endl;
    }
    else {
        cout << "+ Day khong co tinh chat chan le" << endl;
    }

    if (KiemTraToanChan(a, n)) {
        cout << "+ Day co tinh chat toan chan" << endl;
    }
    else {
        cout << "+ Day khong co tinh chat toan chan" << endl;
    }

    // Gi?i ph�ng b? nh?
    delete[] a;

    return 0;
}
