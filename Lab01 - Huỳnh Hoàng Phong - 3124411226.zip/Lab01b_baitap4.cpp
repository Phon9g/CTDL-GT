#include <iostream>

using namespace std;

// H�m nh?p m?ng s? th?c s? d?ng con tr?
void NhapMang(double* a, int n) {
    for (double* p = a; p < a + n; p++) {
        cout << "Phan tu " << (p - a) << ": ";
        cin >> *p;
    }
}

// H�m xu?t m?ng s? th?c s? d?ng con tr?
void XuatMang(double* a, int n) {
    cout << "Day so co " << n << " phan tu: ";
    for (double* p = a; p < a + n; p++) {
        cout << *p << " ";
    }
    cout << endl;
}

// H�m h?p nh?t hai d�y t?ng d?n th�nh m?t d�y t?ng d?n (kh�ng c?n s?p x?p)
void HopNhatMang(double* a, int n, double* b, int m, double* c, int& k) {
    double* pa = a, * pb = b, * pc = c;
    k = 0;

    while (pa < a + n && pb < b + m) {
        if (*pa < *pb) {
            *pc = *pa;
            pa++;
        }
        else {
            *pc = *pb;
            pb++;
        }
        pc++;
        k++;
    }

    // Sao ch�p ph?n c�n l?i c?a a n?u c�
    while (pa < a + n) {
        *pc = *pa;
        pa++;
        pc++;
        k++;
    }

    // Sao ch�p ph?n c�n l?i c?a b n?u c�
    while (pb < b + m) {
        *pc = *pb;
        pb++;
        pc++;
        k++;
    }
}

int main() {
    int n, m, k;

    // Nh?p m?ng a
    cout << "+ Day so a" << endl;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> n;
    double* a = new double[n]; // C?p ph�t b? nh? ??ng
    NhapMang(a, n);

    // Nh?p m?ng b
    cout << "+ Day so b" << endl;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> m;
    double* b = new double[m]; // C?p ph�t b? nh? ??ng
    NhapMang(b, m);

    // C?p ph�t b? nh? ??ng cho m?ng c
    double* c = new double[n + m];

    // G?p hai m?ng a, b th�nh c sao cho v?n t?ng d?n
    HopNhatMang(a, n, b, m, c, k);

    // Xu?t m?ng k?t qu?
    cout << "+ Day so c" << endl;
    XuatMang(c, k);

    // Gi?i ph�ng b? nh? ??ng
    delete[] a;
    delete[] b;
    delete[] c;

    return 0;
}
