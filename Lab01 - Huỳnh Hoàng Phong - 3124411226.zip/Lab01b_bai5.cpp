#include <iostream>
#include <cmath>

using namespace std;

// H�m ki?m tra s? nguy�n t?
bool LaSoNguyenTo(int n) {
    if (n < 2) return false;
    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) return false;
    }
    return true;
}

// H�m l?c s? nguy�n t? t? m?ng a, l?u v�o m?ng b
void TaoMangSoNguyenTo(int* a, int n, int*& b, int& m) {
    m = 0; // S? l??ng ph?n t? trong b
    b = new int[n]; // C?p ph�t ??ng cho m?ng b

    for (int i = 0; i < n; i++) {
        if (LaSoNguyenTo(a[i])) {
            b[m++] = a[i]; // Th�m s? nguy�n t? v�o m?ng b
        }
    }
}

// H�m xu?t m?ng
void XuatMang(int* a, int n) {
    cout << "Day so co " << n << " phan tu: ";
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> n;

    if (n <= 0 || n > 100) {
        cout << "So luong phan tu khong hop le!" << endl;
        return 1;
    }

    int* a = new int[n]; // C?p ph�t ??ng m?ng a

    // Nh?p d�y s?
    for (int i = 0; i < n; i++) {
        cout << "Phan tu " << i << ": ";
        cin >> a[i];
    }

    int* b = nullptr; // M?ng b ch?a s? nguy�n t?
    int m = 0; // S? l??ng ph?n t? c?a b

    // T?o m?ng b ch?a s? nguy�n t?
    TaoMangSoNguyenTo(a, n, b, m);

    // Xu?t m?ng b
    if (m > 0) {
        cout << "+ Mang chua cac so nguyen to" << endl;
        XuatMang(b, m);
    }
    else {
        cout << "+ Khong co so nguyen to trong mang" << endl;
    }

    // Gi?i ph�ng b? nh?
    delete[] a;
    delete[] b;

    return 0;
}
