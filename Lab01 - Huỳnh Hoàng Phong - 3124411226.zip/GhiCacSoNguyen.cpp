#include <stdio.h>
#define MAX 100
#define FO "Data.out"
void NhapMang1C(int a[], int& amp; n)
{
	// Sinh vi�n t? ca?i ???t
}
void OutputData(int a[], int n)
{
	FILE* fo;
	fi = fopen(FI, &quot; wt & quot;);
	if (fo == NULL)
	{
		printf(&quot; Khong the tao file & quot;);
		return;
	}
	fprintf(fo, &quot; % d\n & quot; , n);
	for (int i = 0; i & lt; n; i++)
		fprintf(fo, &quot; % d\n & quot; , a[i]);
	fclose(fo);
}
int main()
{
	int a[MAX];
	int n;
	NhapMang1C(a, n);
	OutputData(a, n);
	return 0;
}