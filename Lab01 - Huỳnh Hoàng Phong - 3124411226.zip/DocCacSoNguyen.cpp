#include <iostream>
#include <cstdio>

using namespace std;

void DocCacSoNguyen(const char* filename) {
    FILE* file = fopen(filename, "r"); // M? file ?? ??c
    if (!file) {
        cout << "Khong the mo file!" << endl;
        return;
    }

    int n;
    fscanf(file, "%d", &n); // ??c s? ph?n t? c?a m?ng

    // C?p ph�t m?ng ??ng ?? l?u c�c s? nguy�n
    int* arr = new int[n];

    // ??c n s? t? file
    for (int i = 0; i < n; i++) {
        fscanf(file, "%d", (arr + i));
    }

    fclose(file); // ?�ng file

    // Xu?t m?ng ra m�n h�nh
    cout << "Cac so trong file la: ";
    for (int i = 0; i < n; i++) {
        cout << *(arr + i) << " ";
    }
    cout << endl;

    delete[] arr; // Gi?i ph�ng b? nh?
}

int main() {
    DocCacSoNguyen("DaySoNguyen.inp");
    return 0;
}
