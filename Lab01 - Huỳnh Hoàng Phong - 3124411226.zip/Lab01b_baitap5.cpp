#include <iostream>

using namespace std;

// H�m nh?p m?ng s? nguy�n s? d?ng con tr?
void NhapMang(int* a, int n) {
    for (int* p = a; p < a + n; p++) {
        cout << "Phan tu " << (p - a) << ": ";
        cin >> *p;
    }
}

// H�m xu?t m?ng s? nguy�n s? d?ng con tr?
void XuatMang(int* a, int n) {
    cout << "Day so co " << n << " phan tu: ";
    for (int* p = a; p < a + n; p++) {
        cout << *p << " ";
    }
    cout << endl;
}

// H�m t�ch m?ng s? nguy�n th�nh m?ng s? ch?n v� m?ng s? l?
void TachChanLe(int* a, int n, int* b, int& nb, int* c, int& nc) {
    nb = nc = 0; // S? l??ng ph?n t? ban ??u c?a b v� c

    for (int* p = a; p < a + n; p++) {
        if (*p % 2 == 0) {
            *(b + nb) = *p; // L?u s? ch?n v�o b
            nb++;
        }
        else {
            *(c + nc) = *p; // L?u s? l? v�o c
            nc++;
        }
    }
}

int main() {
    int n, nb, nc;

    // Nh?p m?ng a
    cout << "+ Day so a" << endl;
    cout << "Moi ban nhap so luong phan tu: ";
    cin >> n;
    int* a = new int[n]; // C?p ph�t ??ng m?ng a
    NhapMang(a, n);

    // C?p ph�t ??ng m?ng b v� c (k�ch th??c t?i ?a l� n)
    int* b = new int[n];
    int* c = new int[n];

    // T�ch m?ng a th�nh b (s? ch?n) v� c (s? l?)
    TachChanLe(a, n, b, nb, c, nc);

    // Xu?t m?ng b (s? ch?n)
    cout << "+ Day so b chua so chan" << endl;
    if (nb > 0) {
        XuatMang(b, nb);
    }
    else {
        cout << "Day so rong." << endl;
    }

    // Xu?t m?ng c (s? l?)
    cout << "+ Day so c chua so le" << endl;
    if (nc > 0) {
        XuatMang(c, nc);
    }
    else {
        cout << "Day so rong." << endl;
    }

    // Gi?i ph�ng b? nh? ??ng
    delete[] a;
    delete[] b;
    delete[] c;

    return 0;
}
