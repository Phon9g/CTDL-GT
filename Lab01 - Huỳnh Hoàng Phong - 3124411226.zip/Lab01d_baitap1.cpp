#include <iostream>
#include <cstring>

using namespace std;

// H�m ho�n v? 2 k� t?
void HoanVi(char* a, char* b) {
    char temp = *a;
    *a = *b;
    *b = temp;
}

// H�m s?p x?p chu?i theo th? t? t?ng d?n (d�ng con tr?)
void SapXepChuoi(char* s) {
    int len = strlen(s);

    // S?p x?p b?ng thu?t to�n Bubble Sort v?i con tr?
    for (char* p1 = s; *p1 != '\0'; p1++) {
        for (char* p2 = p1 + 1; *p2 != '\0'; p2++) {
            if (*p1 > *p2) {
                HoanVi(p1, p2);
            }
        }
    }
}

int main() {
    char s[1001]; // Chu?i t?i ?a 1000 k� t? + 1 k� t? null
    cout << "Moi ban nhap chuoi s: ";
    cin.getline(s, 1001); // ??c c? d�ng bao g?m d?u c�ch

    // S?p x?p chu?i
    SapXepChuoi(s);

    cout << "Chuoi sau khi sap xep: " << s << endl;
    return 0;
}
